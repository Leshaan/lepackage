mypackage

This was an example library of how to publish your own Python package.

installing/building this package locally, run the following in CMD.

'python setup.py sdist'

Issue the command below to install your package from GitHub.
(make sure to replace your-name and your-repo with the appropriate text)

pip install git+https://github.com/your-name/your-repo.git

If you need to install a later version of your package, then use:

pip install --upgrade git+https://github.com/your-name/your-repo.git
